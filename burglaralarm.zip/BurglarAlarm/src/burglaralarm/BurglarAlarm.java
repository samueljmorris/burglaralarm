/**
 *  (Use Javadoc tags to document your code too.
 *
 * @author (your Panther Id)
 *
 * Title:            (program's title)
 * Semester:         COP3337 - Spring 2016
 * Lecturer's Name:  (name of your lecturer)
 *   Description of Program’s Functionality
 *
 *
 *
 *
 */
package burglaralarm;

/**
 *
 * @author jose
 */
public class BurglarAlarm {
    public static boolean alarm = false;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
    }
    
    public static void armAlarm()
    {
        boolean sensorTrip = false;
        
        if (sensorTrip == true)
        {
            alarm = true;
        }
        
    }
    
    public static void disarmAlarm()
    {
       alarm = false; 
    }
    
    public static void detectPerson()
    {
        boolean person = false;
        
        if(person == true)
        {
            alarm = true;
        }
    }
    
//    public static void trainPerson()
//    {
//        //training the recognition using cascade
//    }
    
//    public static void importVideo()
//    {
//        //method to import video for recognition
//    }
    
//      public static void checkSensors()
//      {
//        //loop that checks sensors constantly for data   
//      }
          
        
}
